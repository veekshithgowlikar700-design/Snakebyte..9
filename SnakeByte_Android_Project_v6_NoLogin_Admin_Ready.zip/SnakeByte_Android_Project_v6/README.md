# SnakeByte v6

SnakeByte is a low-end-friendly Android Python learning app. This build is intentionally **login-free** and uses local storage for progress and testing.

## v6 features
- No Google login, OTP, Firebase, or account screen.
- App opens directly to the learning screen.
- One new course topic is available per calendar day.
- Completing today’s topic updates the daily streak.
- A day-unlock animation appears when a new calendar day becomes available.
- After the daily topic is completed, Practice Mode offers unlimited fresh batches of 5 questions.
- Every answered practice question is saved immediately. Completed 5-question batches are counted as practice sets.
- Existing Python code runner and run animation are included.
- Local Admin Panel for testing days, streaks, completion, unlocks, and practice counters.

## Admin Panel
Open **Me → Admin Panel**.

Username: `veekshith`

Password: `Veekshith---`

Admin controls include: complete today, unlock next day, jump to Day 1/last day, add practice counts, add practice sets, unlock all, reset practice, set streak to 7/30, return to real calendar mode, and reset all test data.

> The Admin Panel is a local client-side testing panel, not production-grade authentication.

## GitHub APK build
Upload the contents of this folder to a GitHub repository. The workflow at `.github/workflows/build-apk.yml` runs automatically on pushes to `main`/`master`, or manually from **Actions → Build SnakeByte APK → Run workflow**.

The workflow installs Gradle 8.7 and Java 17, runs `gradle assembleDebug`, and uploads `SnakeByte-v6-debug-apk`.

## Repository layout
```text
SnakeByte/
├── .github/workflows/build-apk.yml
├── app/
├── build.gradle
├── gradle.properties
└── settings.gradle
```
